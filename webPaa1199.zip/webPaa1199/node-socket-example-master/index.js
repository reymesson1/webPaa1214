var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var Kafka = require('no-kafka');
var producer = new Kafka.Producer();

var second = 59;

app.get('/', function(req, res){
    res.sendFile(__dirname + '/chat.html');
});

io.on('connection', function(socket){
    console.log('a user connected');
    socket.on('joined', function(data) {
        console.log(data);
        socket.emit('acknowledge', 'Acknowledged');
    });
    socket.on('chat message', function(msg){
        console.log('message: ' + msg);
        second = 31;
        socket.emit('response message', msg + '  from server');
        //socket.broadcast.emit('response message', msg + '  from server');
    });
});

function timeoutFunc() {
    
        producer.init().then(function(){
        producer.send({
                topic: 'test',
                partition: 0,
                message: {
                    value: ''+second
                }
            });
        })
        .then(function (result) {
            /*
            [ { topic: 'kafka-test-topic', partition: 0, offset: 353 } ]
            */
        });
    
        if(second>-1){
            
            second--
            
        }else{
            
            second = 59
        }

        setTimeout(timeoutFunc, 1000);
}
    
timeoutFunc();

http.listen(8080, function(){
    console.log('listening on *:8080');
});