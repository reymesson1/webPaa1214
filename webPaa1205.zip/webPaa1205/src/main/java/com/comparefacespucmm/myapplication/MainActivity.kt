package com.comparefacespucmm.myapplication

import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    var longitute = ""
    var latitute = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)




        var permissionCheck = ContextCompat.checkSelfPermission(

            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if(permissionCheck!= PackageManager.PERMISSION_GRANTED){

            if(this.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION)){

                var check=false
            }

        }else{

            var check=true
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        fusedLocationClient.lastLocation
            .addOnSuccessListener {

                Log.i("location", it.latitude.toString())
                val sydney = LatLng(it.latitude, it.longitude)
                latitute = it.latitude.toString()
                longitute = it.longitude.toString()


                mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
                var ubicate = CameraUpdateFactory.newLatLng(sydney)
                var zoom = CameraUpdateFactory.zoomTo(14.toFloat())
                mMap.moveCamera(ubicate)
                mMap.animateCamera(zoom)

            }

        btn_add.setOnClickListener {

            Toast.makeText(this, "Location recorded successfully completed $longitute $latitute ", Toast.LENGTH_SHORT).show()
        }


    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera

    }

}
