package com.comparefacespucmm.myapplication

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.activity_main.*
import android.hardware.SensorManager


class MainActivity : AppCompatActivity(), OnMapReadyCallback, SensorEventListener {

    private lateinit var mMap: GoogleMap
    private lateinit var sensorManager: SensorManager

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    var longitute = ""
    var latitute = ""

    var x : Float = Float.MIN_VALUE;
    var y : Float = Float.MIN_VALUE;
    var z : Float = Float.MIN_VALUE;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        sensorManager.registerListener(
            this,
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
            SensorManager.SENSOR_DELAY_NORMAL
        )

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)




        var permissionCheck = ContextCompat.checkSelfPermission(

            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if(permissionCheck!= PackageManager.PERMISSION_GRANTED){

            if(this.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION)){

                var check=false
            }

        }else{

            var check=true
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        fusedLocationClient.lastLocation
            .addOnSuccessListener {

                Log.i("location", it.latitude.toString())
                val sydney = LatLng(it.latitude, it.longitude)
                latitute = it.latitude.toString()
                longitute = it.longitude.toString()


                mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
                var ubicate = CameraUpdateFactory.newLatLng(sydney)
                var zoom = CameraUpdateFactory.zoomTo(14.toFloat())
                mMap.moveCamera(ubicate)
                mMap.animateCamera(zoom)

            }

        btn_add.setOnClickListener {

            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (vibrator.hasVibrator()) { // Vibrator availability checking
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE)) // New vibrate method for API Level 26 or higher
                } else {
                    vibrator.vibrate(500) // Vibrate method for below API Level 26
                }
            }

            Toast.makeText(this, "Location recorded successfully completed $longitute $latitute ", Toast.LENGTH_SHORT).show()

        }


    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera

    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }

    override fun onSensorChanged(event: SensorEvent?) {

        btn_sensor_x.setText("X: "+event!!.values[0] + " Y: " + event!!.values[1] + " Z: " + event!!.values[2])

    }



}
