package com.comparefacespucmm.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.layout_item.view.*
import org.json.JSONArray
import org.json.JSONObject


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var item = layoutInflater.inflate(R.layout.layout_item,null)

        var socket = IO.socket("http://190.94.2.105:8081")




        socket.let {
            it!!.connect()
                .on(Socket.EVENT_CONNECT) {
                    Log.d("SignallingClient", "Socket connected!!!!!")
                }
        }

        btn_add.setOnClickListener {at->

            Log.d("SignallingClientNEW","sent")




            socket.let {et->

                Log.d("SignallingClientNEW",et.toString())

                    et.on("update"){ ot->


//                        var json = Gson().toJson(ot)

                        var jsonarray = JSONArray(ot)

                        Log.d("SignallingClientNEW",  jsonarray[0].toString() )

//                        item.nameTXT.setText(ot)
                    }
                socket.connect()

            }

        }




    }

}
