package com.comparefacespucmm.myapplication

class Master{

    var second = ""
    var latitude = ""
    var longitude = ""
    var redlight = ""

}