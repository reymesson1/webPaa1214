package com.comparefacespucmm.myapplication

import android.util.Log
import com.google.gson.Gson
import io.socket.client.IO
import io.socket.client.Socket
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync

class RestAPI{

    private var socket = IO.socket("http://190.94.2.105:8081")

    val jsonStr="""
    {
     "second":52,"latitude":0,"longitude":0,"redlight":false
    }
    """.trimIndent()

    data class Information(val second:Int,val latitude:Int, val longitude:Int,  val redlight:Boolean)

    var local = arrayListOf<String>()

    fun onProcess(){

        socket.let {at->
            at!!.connect()
                .on(Socket.EVENT_CONNECT) {

                    Log.i("SignallingClient", "Socket connected!!!!!")
                }
        }

        socket.let {at->
            at.on("update"){et->

//                val information:Information= Gson().fromJson<Information>(jsonStr,Information::class.java)
                val information:Information= Gson().fromJson<Information>(et[0].toString(),Information::class.java)

                //local = information.toString()

                local.add(information.toString())

                Log.i("SignallingClientNEW", information.redlight.toString())
            }

        }

    }

    fun onClean(){

        //local.clear()

        socket.disconnect()

    }

    fun showSize() : Int{

        Log.i("response", local.size.toString())

        return local.size
    }





}