package com.comparefacespucmm.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var socket = IO.socket("http://190.94.2.105:8080")
        socket.let {
            it!!.connect()
                .on(Socket.EVENT_CONNECT) {
                    Log.d("SignallingClient", "Socket connected!!!!!")
                }
        }

        btn_add.setOnClickListener {

            socket.emit("chat message", "test")

            socket.connect()

        }

    }

}
