package com.comparefacespucmm.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync


data class Information(val second:Int,val latitude:Int, val longitude:Int, val redlight:Boolean)

var local = arrayListOf<Information>()

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_add.setOnClickListener {

            var socket = IO.socket("http://190.94.2.105:8080")
            socket.let {
                it!!.connect()
                    .on(Socket.EVENT_CONNECT) {
                        Log.d("SignallingClient", "Socket connected!!!!!")
                    }
            }

            var socketO = IO.socket("http://190.94.2.105:8081")
            socketO.let {
                it!!.connect()
                    .on(Socket.EVENT_CONNECT) {
                        Log.d("SignallingClient", "Socket connected UPDATE!!!!!")
                    }
            }

            doAsync {

                activityUiThread {

                    Thread.sleep(2000)



                    socketO.let { et ->

                        et.on("update") { ot ->

                            val information:Information= Gson().fromJson<Information>(ot[0].toString(),Information::class.java)
                            Log.d("SignallingClientNEW", information.toString())
                            local.add(information)
                        }
                    }
                }
            }

            doAsync {

                activityUiThread {

                    Thread.sleep(4000)
                    socketO.disconnect()
                }
            }

            doAsync {

                activityUiThread {

                    Thread.sleep(6000)

                    if(local[0].second>30&&!local[0].redlight){

                        socket.connect()

                        socket.emit("chat message", "test "+local.size)

                        socket.connect()
                    }



                }
            }


            local.clear()

        }

    }

}
