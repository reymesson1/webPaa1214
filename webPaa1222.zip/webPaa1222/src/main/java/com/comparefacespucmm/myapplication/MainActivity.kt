package com.comparefacespucmm.myapplication

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.gson.Gson
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.layout_item.view.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync
import org.json.JSONArray
import org.json.JSONObject


class MainActivity : AppCompatActivity() , OnMapReadyCallback, SensorEventListener {

    var longitute = ""
    var latitute = ""
    var X = 0.00f
    var Y = 0.00f
    var Z = 0.00f

    var localCounter = 0

    private lateinit var sensorManager: SensorManager

    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    data class Information(val second:Int,val latitude:Int, val longitude:Int, val redlight:Boolean, val people: Boolean, val secondpeople:Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        sensorManager.registerListener(
            this,
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
            SensorManager.SENSOR_DELAY_NORMAL
        )

//        var socket = IO.socket("http://10.28.130.218:8081")
//        var socket = IO.  socket("http://10.0.0.22:8081")
//        var socket = IO.socket("http://192.168.43.121:8081")
        var socket = IO.socket("http://190.94.2.105:8081")

        socket.let {
            it!!.connect()
                .on(Socket.EVENT_CONNECT) {
                    Log.d("SignallingClient", "Socket connectedEMIT!!!!!")
                }
        }

        doAsync {
            activityUiThread {
                Thread.sleep(2000)
                socket.let { et ->
                    et.on("update red") { ot ->
                        val information:Information= Gson().fromJson<Information>(ot[0].toString(),Information::class.java)
//                        if(information.people&&((information.second%10)==0)){
                        if(information.redlight&&((information.second%10)==0)){
                            Log.d("SignallingClientNEW", information.toString())
                            onVibes()
//                            onMapa()
                        }
                    }
                }
            }
        }

        btn_check.setOnClickListener {

            var socketI = IO.socket("http://190.94.2.105:8080")
            socketI.let {
                it!!.connect()
                    .on(Socket.EVENT_CONNECT) {
                        Log.d("SignallingClient", "Socket connectedEMIT!!!!!")
                    }
            }

            doAsync {

                activityUiThread {

                    Thread.sleep(2000)


                        socketI.connect()

                        socketI.emit("chat message two", "test "+localCounter)

                        socketI.connect()



                }
            }

//            Toast.makeText(this@MainActivity, "X: "+latitute + "Y: "+ longitute, Toast.LENGTH_LONG ).show()
            Toast.makeText(this@MainActivity, "X: "+X + " Y: "+ Y + " Z: " + Z + " Counter: " + localCounter, Toast.LENGTH_LONG ).show()
        }

    }

    fun onVibes(){

        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (vibrator.hasVibrator()) { // Vibrator availability checking
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE)) // New vibrate method for API Level 26 or higher
            } else {
                vibrator.vibrate(500) // Vibrate method for below API Level 26
            }
        }
    }

    fun onMapa(){

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        var permissionCheck = ContextCompat.checkSelfPermission(

            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)


        fusedLocationClient.lastLocation
            .addOnSuccessListener {

                latitute = it.latitude.toString()
                longitute = it.longitude.toString()

                val sydney = LatLng(it.latitude, it.longitude)
                mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
                var ubicate = CameraUpdateFactory.newLatLng(sydney)
                var zoom = CameraUpdateFactory.zoomTo(14.toFloat())
                mMap.moveCamera(ubicate)
                mMap.animateCamera(zoom)


            }


        Toast.makeText(this@MainActivity, "X: "+latitute + "Y: "+ longitute, Toast.LENGTH_LONG ).show()

    }


    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }

    override fun onSensorChanged(event: SensorEvent?) {

        X = event!!.values[0]
        Y = event!!.values[1]
        Y = event!!.values[2]

        if(Y >= 10.00){
            localCounter++
        }

//        btn_sensor_x.setText("X: "+event!!.values[0] + " Y: " + event!!.values[1] + " Z: " + event!!.values[2])
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera

    }


}
