package com.comparefacespucmm.myapplication

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync


data class Information(val second:Int,val latitude:Int, val longitude:Int, val redlight:Boolean)

var local = arrayListOf<Information>()
var check = false

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        var socket = IO.socket("http://192.168.43.121:8080")
        var socket = IO.socket("http://190.94.2.105:8080")
        socket.let {
            it!!.connect()
                .on(Socket.EVENT_CONNECT) {
                    Log.d("SignallingClient", "Socket connected!!!!!")
                }
        }

//        var socketO = IO.socket("http://192.168.43.121:8081")
        var socketO = IO.socket("http://190.94.2.105:8081")
        socketO.let {
            it!!.connect()
                .on(Socket.EVENT_CONNECT) {
                    Log.d("SignallingClient", "Socket connected UPDATE!!!!!")
                }
        }

        doAsync {

            activityUiThread {

                Thread.sleep(2000)

                socketO.let { et ->

                    et.on("update green") { ot ->

                        if(check){

                            socket.emit("chat message", "test "+local.size)

                            socket.connect()

                            check = false
                        }

                    }
                }
            }
        }

        btn_add.setOnClickListener {

            check = true
        }

        btn_cancelar.setOnClickListener {

            check = false
        }

    }

}
