package com.comparefacespucmm.myapplication.Model

class Login{

    var id : String = ""
    var date : String = ""
    var username : String = ""
    var token : String = ""

}