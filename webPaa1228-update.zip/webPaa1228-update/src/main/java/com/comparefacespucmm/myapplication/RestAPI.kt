package com.comparefacespucmm.myapplication

import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat.startActivity
import androidx.lifecycle.MutableLiveData
import com.comparefacespucmm.myapplication.Model.Login
import com.comparefacespucmm.myapplication.Model.MasterService
import com.comparefacespucmm.myapplication.Model.MasterServicePost
import com.google.gson.Gson
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*

class RestAPI{

    var retrofit = Retrofit.Builder()
        .baseUrl("http://190.94.2.105:8084/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    var token : String = ""

    fun getMasterAPI() : MasterService{

        return retrofit.create(MasterService::class.java)
    }


    fun setMasterAPI(name:String){

        var newMaster = Login()
        newMaster.id = Date().time.toString()
        newMaster.date = Date().toString()
        newMaster.username = name

        var json = Gson().toJson(newMaster)

        var masterServicePost = retrofit.create(MasterServicePost::class.java)

        var call = masterServicePost.setMaster(JSONObject(json))

        call.enqueue(object : Callback<Login>{
            override fun onFailure(call: Call<Login>, t: Throwable) {
                Log.i("error2", t.toString())
            }

            override fun onResponse(call: Call<Login>, response: Response<Login>) {

                Log.i("response", response.body()!!.token)

                token = response.body()!!.token
            }

        })

    }
}