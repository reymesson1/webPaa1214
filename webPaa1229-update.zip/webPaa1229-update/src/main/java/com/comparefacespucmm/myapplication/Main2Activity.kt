package com.comparefacespucmm.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main2.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync

class Main2Activity : AppCompatActivity() {

    var rest = RestAPI()
    var username = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        btn_login.setOnClickListener {

            username = nameTXTLogin.text.toString()

            rest.setMasterAPI(username)

            doAsync {

                activityUiThread {

                    Thread.sleep(2000)

                    rest.setMasterAPI(username)
                }
            }

            doAsync {

                activityUiThread {

                    Thread.sleep(4000)

                    if(rest.token.length>0){
                        var intent = Intent(this@Main2Activity, MainActivity::class.java)
                        intent.putExtra("token", rest.token)
                        startActivity(intent)
                    }

                }
            }

        }

    }

}
