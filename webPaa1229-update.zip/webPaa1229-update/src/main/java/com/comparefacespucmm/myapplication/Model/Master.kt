package com.comparefacespucmm.myapplication.Model

class Master{

    var redlight : String = ""
    var date : String = ""
    var step : String = ""
    var distance : Int = 0
    var token : String = ""
}