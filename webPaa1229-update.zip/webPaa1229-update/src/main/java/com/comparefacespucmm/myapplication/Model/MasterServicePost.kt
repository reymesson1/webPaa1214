package com.comparefacespucmm.myapplication.Model

import org.json.JSONObject
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Call

interface MasterServicePost{

    @POST("login")

    fun setMaster(@Body data : JSONObject) : Call<Login>

}